# Deployed Project Link
https://workoutfrontend-vzkl.onrender.com

# Project Description
A MERN stack project using cors for resourse sharing & mongodb atlas as a database.
You can add and delete a workout, the details are such that the newly added workout is shown up instantly on the homepage(context creation).

# Still working on the authentication part.
